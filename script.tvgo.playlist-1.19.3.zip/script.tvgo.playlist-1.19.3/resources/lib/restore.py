import tvgo


tvgo.restore_token()