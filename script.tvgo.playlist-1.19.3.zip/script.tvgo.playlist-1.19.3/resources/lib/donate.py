# -*- coding: utf-8 -*-

import xbmc
xbmc.executebuiltin('ShowPicture('+ 'https://raw.githubusercontent.com/top9/TMTV-go-playlist/main/KBdonate.png'+')')