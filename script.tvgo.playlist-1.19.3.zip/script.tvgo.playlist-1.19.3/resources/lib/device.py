import tvgo


tvgo.delete_device()