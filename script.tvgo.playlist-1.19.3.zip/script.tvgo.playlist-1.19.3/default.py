from resources.lib import tvgo
import routing, sys


plugin = routing.Plugin()


@plugin.route('/catchup/<id>/<time>')
def catchup(id, time):
    tvgo.catchup(id, time)


@plugin.route('/record/<name>/<time>/<file_name>')
def record(name, time, file_name):
    tvgo.record(name, time, file_name)


@plugin.route('/play/<id>')
def play(id):
    tvgo.play(id)


@plugin.route('/')
def start():
    tvgo.playlist(True, True)


@plugin.route('default.py')
def start_():
    if len(sys.argv) > 1:
        tvgo.playlist(True, False)
    else:
        tvgo.playlist(True, True)


if (__name__ == "__main__"):
    plugin.run()